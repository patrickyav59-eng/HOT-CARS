# Hot Cars — Static Site

Minimal static HTML/CSS site scaffold for listing cars and capturing leads.

Files created:
- [index.html](index.html)
- [inventory.html](inventory.html)
- [cars/car-1.html](cars/car-1.html)
- [styles/styles.css](styles/styles.css)

Next steps:
- Replace `assets/car-sample.jpg` with real photos in `assets/`.
- Update the contact form action in `index.html` to your Formspree or form endpoint.
- Upload these files to your hosting provider and point your domain.
